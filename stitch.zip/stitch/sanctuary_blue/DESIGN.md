```markdown
# Design System Strategy: The Digital Sanctuary

## 1. Overview & Creative North Star
**Creative North Star: "The Sacred Editorial"**

This design system moves away from the sterile, "admin-panel" aesthetic typical of information systems. Instead, it adopts a high-end editorial approach that balances the solemnity of faith with the warmth of community. We achieve this through **Intentional Asymmetry**—where large serif headings are offset against structured UI elements—and **Tonal Depth**, replacing harsh lines with soft layers of color. The goal is to make the user feel they are entering a quiet, well-ordered space of reflection rather than a database.

---

## 2. Colors: Depth Over Definition
Our palette is rooted in the "Deep Blue" of tradition and the "Soft Gold" of candlelight.

### The "No-Line" Rule
Standard 1px borders are strictly prohibited for sectioning. We define boundaries through **Background Color Shifts**. 
- A section of content should sit on `surface-container-low`, while the main page remains `surface`. 
- To separate a sidebar from a main feed, use a transition from `surface` to `surface-container-high`.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of fine paper.
- **Base Layer:** `surface` (#faf9fc).
- **Secondary Areas:** `surface-container-low` (#f4f3f7) for subtle grouping.
- **Interactive Containers:** `surface-container-lowest` (#ffffff) for cards and modals to create a "lifted" feel.

### The "Glass & Gradient" Rule
For high-impact areas like hero sections or "Booking Kembang Altar" prompts, use a **Signature Gradient**:
- Linear 135°: `primary` (#022448) → `primary-container` (#1e3a5f).
- Floating navigation should utilize **Glassmorphism**: `surface` at 80% opacity with a `backdrop-blur: 20px` to maintain a sense of airiness.

---

## 3. Typography: The Modern Liturgy
We pair the intellectual authority of a Serif with the functional clarity of a Sans-Serif.

- **Display & Headlines (Noto Serif):** Used for spiritual quotes, page titles, and major announcements. The serif adds a "graceful" and "timeless" quality.
  - *Strategy:* Use `display-lg` for impactful landing moments. Use `headline-sm` for card titles to give them an editorial feel.
- **UI & Body (Manrope):** A modern sans-serif designed for legibility in dense information (schedules, forms).
  - *Strategy:* Use `body-md` for all paragraph text. Use `label-md` (All Caps, 0.05rem letter-spacing) for categories like "Liturgy" or "Events."

---

## 4. Elevation & Depth: Tonal Layering
We reject the "drop-shadow" defaults of 2010. Hierarchy is achieved through light and layering.

- **The Layering Principle:** To highlight an announcement, place a `surface-container-lowest` card on a `surface-container` background. The contrast in lightness provides enough "lift" without visual noise.
- **Ambient Shadows:** When an element must float (e.g., a Booking Modal), use:
  - `box-shadow: 0 12px 40px rgba(26, 28, 30, 0.06);` (Using a 6% opacity of the `on-surface` color).
- **The Ghost Border:** If a form input requires a container, use `outline-variant` (#c4c6cf) at **15% opacity**. It should be felt, not seen.

---

## 5. Components

### Buttons: The Call to Action
- **Primary (The Golden Path):** Uses `tertiary-fixed` (#ffdea5) with `on-tertiary-fixed` (#261900). For "Booking Kembang Altar," this soft gold provides warmth and high visibility without the aggression of "Internet Red."
- **Secondary:** `primary` background with `on-primary` text. Use for routine actions like "View Schedule."
- **Shape:** Use `rounded-md` (0.75rem) for a friendly but professional corner.

### Cards & Lists: The Editorial Feed
- **Announcement Cards:** No borders. Use `surface-container-lowest` with a 24pt (`spacing-6`) internal padding. 
- **The "No-Divider" Rule:** In schedules (Tables), do not use horizontal lines. Separate rows using alternating background shifts (`surface` vs `surface-container-low`) or 16px (`spacing-4`) of vertical whitespace.
- **Image Treatment:** Use `rounded-lg` (1rem) for all images. Apply a subtle 10% `primary` color overlay to images in headers to ensure text legibility.

### Input Fields & Booking Features
- **Booking Inputs:** Use `surface-container-high` as the background for input fields. No bottom border. On focus, transition the background to `surface-container-highest`.
- **Chips:** For filtering schedules (e.g., "Mass," "Wedding," "Baptism"), use `secondary-container` with `on-secondary-container` text.

### Specialized Component: The "Altar Status" Ledger
- For "Booking Kembang Altar," use a custom table with **asymmetric spacing**. The date should be in a large `title-lg` (Manrope), while the availability details sit in `label-sm` to create a clear visual hierarchy of "When" vs "What."

---

## 6. Do’s and Don’ts

### Do:
- **Use White Space as a Tool:** Use `spacing-12` (3rem) between major sections to let the design breathe.
- **Embrace Asymmetry:** Align headings to the left while keeping action buttons to the right to create a sophisticated, non-template look.
- **Use Tonal Color:** Always use `on-surface-variant` (#43474e) for secondary text to maintain a soft, welcoming contrast.

### Don’t:
- **No Pure Black:** Never use #000000. Use `on-background` (#1a1c1e) for text to keep the interface feeling premium.
- **No 1px Dividers:** Do not use `<hr>` tags or 1px borders to separate content. Use background color steps or whitespace.
- **No Default Shadows:** Avoid the "fuzzy grey" shadow. If you need depth, use the Ambient Shadow formula or a Tonal Shift.
- **No All-Caps Serifs:** Keep Noto Serif in sentence case to maintain its graceful, "human" quality. Use Manrope for all-caps labels.